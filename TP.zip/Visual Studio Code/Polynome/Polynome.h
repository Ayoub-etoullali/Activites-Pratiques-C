#ifndef _POLYNOME
    #define _POLYNOME
    #include"Polynome_t.h"
    poly_t saisir();
    void afficher(poly_t );
    double eval(poly_t,double);
#endif