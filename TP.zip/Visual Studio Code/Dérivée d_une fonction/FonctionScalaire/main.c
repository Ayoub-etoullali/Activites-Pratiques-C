//
//  main.c
//  FonctionScalaire
//
//  Created by Aya Ait on 11/25/21.
//  Copyright © 2021 Aya Ait. All rights reserved.
//

#include <stdio.h>
#include "FonctionScalaire.h"
#include "FonctionScalaire.c"

int main(int argc, const char * argv[]) {
    // insert code here...
    menu();
    return 0;
}
