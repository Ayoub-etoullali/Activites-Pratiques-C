#ifndef _FCT_SCALAIRE
    #define _FCT_SCALAIRE
    #define H_MAX 0.25
    double f(double);

    double fPrime(double,double);

    double fSeconde(double,double);
    int getSgnFSeconde(double, double);
    //double integraleF(double,double);
    void menu();
#endif